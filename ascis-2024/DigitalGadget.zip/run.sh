#!/bin/bash
docker compose up -d --force-recreate --build